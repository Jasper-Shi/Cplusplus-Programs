//tools.h
#ifndef NAMESPACE_TOOLS_H
#define NAMESPACE_TOOLS_H
// Performs a fool-proof integer entry
int getInt(int min, int max);
// Displays the user interface menu
int menu();
#endif